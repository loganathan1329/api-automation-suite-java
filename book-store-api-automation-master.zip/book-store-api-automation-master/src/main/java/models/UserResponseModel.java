package models;

import lombok.Data;

@Data
public class UserResponseModel {
    private String responseMessage;
    private String message;
}
